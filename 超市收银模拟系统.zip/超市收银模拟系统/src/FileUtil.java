import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * 文件操作工具类
 * 负责会员信息文件和销售记录文件的读写操作
 * 所有文件操作使用 UTF-8 编码，确保中文正常显示
 */
public class FileUtil {

    private static final String MEMBERS_FILE = "members.txt";

    private static final String SALES_FILE = "sales.txt";

    private static final Object MEMBER_LOCK = new Object();

    private static final Object SALES_LOCK = new Object();

    /**
     * 保存会员信息到会员文件（追加写入）
     * @param member 会员对象
     */
    public static void saveMember(Member member) {
        synchronized (MEMBER_LOCK) {
            try (BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(new FileOutputStream(MEMBERS_FILE, true), StandardCharsets.UTF_8))) {
                writer.write(member.toFileString());
                writer.newLine();
                writer.flush();
            } catch (IOException e) {
                System.err.println("保存会员信息失败：" + e.getMessage());
            }
        }
    }

    /**
     * 从会员文件中加载所有会员信息
     * @return 会员列表
     */
    public static List<Member> loadAllMembers() {
        List<Member> members = new ArrayList<>();
        File file = new File(MEMBERS_FILE);
        if (!file.exists()) {
            return members;
        }
        synchronized (MEMBER_LOCK) {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    Member member = Member.fromFileString(line);
                    if (member != null) {
                        members.add(member);
                    }
                }
            } catch (IOException e) {
                System.err.println("读取会员信息失败：" + e.getMessage());
            }
        }
        return members;
    }

    /**
     * 根据会员ID查找会员
     * @param memberId 会员ID
     * @return 找到的会员对象，未找到返回null
     */
    public static Member findMemberById(String memberId) {
        List<Member> members = loadAllMembers();
        for (Member m : members) {
            if (m.getMemberId().equals(memberId)) {
                return m;
            }
        }
        return null;
    }

    /**
     * 根据手机号查找会员
     * @param phone 手机号
     * @return 找到的会员对象，未找到返回null
     */
    public static Member findMemberByPhone(String phone) {
        List<Member> members = loadAllMembers();
        for (Member m : members) {
            if (m.getPhone().equals(phone)) {
                return m;
            }
        }
        return null;
    }

    /**
     * 检查会员ID或手机号是否已存在
     * @param memberId 会员ID
     * @param phone    手机号
     * @return 存在返回true
     */
    public static boolean isMemberExists(String memberId, String phone) {
        List<Member> members = loadAllMembers();
        for (Member m : members) {
            if (m.getMemberId().equals(memberId) || m.getPhone().equals(phone)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 自动生成会员ID
     * 格式：M + 日期(yyyyMMdd) + 3位序号（如 M20260515001）
     * @return 新生成的会员ID
     */
    public static String generateMemberId() {
        String dateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        List<Member> members = loadAllMembers();
        int maxSeq = 0;
        String prefix = "M" + dateStr;
        for (Member m : members) {
            String mid = m.getMemberId();
            if (mid != null && mid.startsWith(prefix) && mid.length() == prefix.length() + 3) {
                try {
                    int seq = Integer.parseInt(mid.substring(prefix.length()));
                    if (seq > maxSeq) {
                        maxSeq = seq;
                    }
                } catch (NumberFormatException e) {
                    // 忽略格式不正确的ID
                }
            }
        }
        return prefix + String.format("%03d", maxSeq + 1);
    }

    /**
     * 保存交易记录到销售文件（追加写入）
     * @param transaction 交易对象
     */
    public static void saveTransaction(Transaction transaction) {
        synchronized (SALES_LOCK) {
            try (BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(new FileOutputStream(SALES_FILE, true), StandardCharsets.UTF_8))) {
                writer.write(transaction.toFileString());
                writer.newLine();
                writer.flush();
            } catch (IOException e) {
                System.err.println("保存交易记录失败：" + e.getMessage());
            }
        }
    }

    /**
     * 加载所有交易记录
     * @return 交易记录列表
     */
    public static List<Transaction> loadAllTransactions() {
        List<Transaction> transactions = new ArrayList<>();
        File file = new File(SALES_FILE);
        if (!file.exists()) {
            return transactions;
        }
        synchronized (SALES_LOCK) {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    Transaction transaction = Transaction.fromFileString(line);
                    if (transaction != null) {
                        transactions.add(transaction);
                    }
                }
            } catch (IOException e) {
                System.err.println("读取交易记录失败：" + e.getMessage());
            }
        }
        return transactions;
    }

    /**
     * 根据日期查询当日的交易记录
     * @param date 查询日期
     * @return 当日交易记录列表
     */
    public static List<Transaction> loadTransactionsByDate(LocalDate date) {
        List<Transaction> allTransactions = loadAllTransactions();
        List<Transaction> result = new ArrayList<>();
        for (Transaction t : allTransactions) {
            if (t.getDateTime().toLocalDate().equals(date)) {
                result.add(t);
            }
        }
        return result;
    }

    /**
     * 自动生成交易ID
     * 格式：T + 日期(yyyyMMdd) + 3位序号（如 T20260515001）
     * @return 新生成的交易ID
     */
    public static String generateTransactionId() {
        String dateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        List<Transaction> transactions = loadAllTransactions();
        int maxSeq = 0;
        String prefix = "T" + dateStr;
        for (Transaction t : transactions) {
            String tid = t.getTransactionId();
            if (tid != null && tid.startsWith(prefix) && tid.length() == prefix.length() + 3) {
                try {
                    int seq = Integer.parseInt(tid.substring(prefix.length()));
                    if (seq > maxSeq) {
                        maxSeq = seq;
                    }
                } catch (NumberFormatException e) {
                    // 忽略格式不正确的ID
                }
            }
        }
        return prefix + String.format("%03d", maxSeq + 1);
    }

    /**
     * 确保数据文件所在目录存在（无需创建子目录，文件直接放在当前工作目录）
     */
    public static void ensureDataFilesExist() {
        try {
            File membersFile = new File(MEMBERS_FILE);
            if (!membersFile.exists()) {
                membersFile.createNewFile();
            }
            File salesFile = new File(SALES_FILE);
            if (!salesFile.exists()) {
                salesFile.createNewFile();
            }
        } catch (IOException e) {
            System.err.println("创建数据文件失败：" + e.getMessage());
        }
    }
}
