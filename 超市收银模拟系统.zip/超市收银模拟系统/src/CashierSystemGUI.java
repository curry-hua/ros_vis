import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 简易超市收银模拟系统 - GUI版
 * 使用 Java Swing 实现图形用户界面
 * 复用 Member、Product、Transaction、FileUtil 四个实体/工具类
 */
public class CashierSystemGUI {

    private static final Pattern PHONE_PATTERN = Pattern.compile("^1[3-9]\\d{9}$");
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final Font TITLE_FONT = new Font("微软雅黑", Font.BOLD, 20);
    private static final Font LABEL_FONT = new Font("微软雅黑", Font.PLAIN, 14);
    private static final Font BUTTON_FONT = new Font("微软雅黑", Font.PLAIN, 14);
    private static final Font DATA_FONT = new Font("微软雅黑", Font.PLAIN, 13);

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // 使用默认外观
        }
        FileUtil.ensureDataFilesExist();
        showMainWindow();
    }

    /**
     * 主菜单窗口
     */
    private static void showMainWindow() {
        JFrame frame = new JFrame("简易超市收银模拟系统");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(480, 440);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        JLabel titleLabel = new JLabel("简易超市收银模拟系统");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel separator = new JLabel("━━━━━━━━━━━━━━━━━━━━");
        separator.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        separator.setAlignmentX(Component.CENTER_ALIGNMENT);
        separator.setForeground(Color.GRAY);

        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(5));
        panel.add(separator);
        panel.add(Box.createVerticalStrut(25));

        JButton btnMember = createMenuButton("  会员管理（办理/查询会员）");
        JButton btnCheckout = createMenuButton("  收银结算");
        JButton btnDateQuery = createMenuButton("  按日期查询销售数据");
        JButton btnGlobal = createMenuButton("  全局销售统计");
        JButton btnExit = createMenuButton("  退出系统");

        btnMember.addActionListener(e -> showMemberDialog(frame));
        btnCheckout.addActionListener(e -> showCheckoutDialog(frame));
        btnDateQuery.addActionListener(e -> showDateQueryDialog(frame));
        btnGlobal.addActionListener(e -> showGlobalStatsDialog(frame));
        btnExit.addActionListener(e -> {
            JOptionPane.showMessageDialog(frame, "感谢使用，再见！", "退出",
                    JOptionPane.INFORMATION_MESSAGE);
            frame.dispose();
        });

        panel.add(btnMember);
        panel.add(Box.createVerticalStrut(10));
        panel.add(btnCheckout);
        panel.add(Box.createVerticalStrut(10));
        panel.add(btnDateQuery);
        panel.add(Box.createVerticalStrut(10));
        panel.add(btnGlobal);
        panel.add(Box.createVerticalStrut(10));
        panel.add(btnExit);

        frame.add(panel);
        frame.setVisible(true);
    }

    /**
     * 创建统一样式的菜单按钮
     */
    private static JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(BUTTON_FONT);
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setMaximumSize(new Dimension(380, 45));
        btn.setPreferredSize(new Dimension(380, 45));
        btn.setFocusPainted(false);
        return btn;
    }

    /**
     * 创建统一样式的标签
     */
    private static JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(LABEL_FONT);
        return label;
    }

    /**
     * 会员管理弹窗
     */
    private static void showMemberDialog(JFrame parent) {
        JDialog dialog = new JDialog(parent, "会员管理", true);
        dialog.setSize(500, 380);
        dialog.setLocationRelativeTo(parent);
        dialog.setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(LABEL_FONT);

        // 标签1：办理新会员
        tabbedPane.addTab("办理新会员", createRegisterMemberPanel(dialog));
        // 标签2：查询会员
        tabbedPane.addTab("查询会员", createQueryMemberPanel());

        dialog.add(tabbedPane, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    /**
     * 办理新会员面板
     */
    private static JPanel createRegisterMemberPanel(JDialog dialog) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JLabel titleLabel = new JLabel("办理新会员");
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(20));

        JPanel namePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        namePanel.add(createLabel("会员姓名："));
        JTextField nameField = new JTextField(15);
        nameField.setFont(LABEL_FONT);
        namePanel.add(nameField);
        panel.add(namePanel);
        panel.add(Box.createVerticalStrut(12));

        JPanel phonePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        phonePanel.add(createLabel("手机号：    "));
        JTextField phoneField = new JTextField(15);
        phoneField.setFont(LABEL_FONT);
        phonePanel.add(phoneField);
        panel.add(phonePanel);
        panel.add(Box.createVerticalStrut(20));

        JButton submitBtn = new JButton("立即办理");
        submitBtn.setFont(BUTTON_FONT);
        submitBtn.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextArea resultArea = new JTextArea(5, 30);
        resultArea.setFont(DATA_FONT);
        resultArea.setEditable(false);
        resultArea.setBackground(new Color(245, 245, 245));
        JScrollPane scrollPane = new JScrollPane(resultArea);
        scrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);

        submitBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String phone = phoneField.getText().trim();
            if (name.isEmpty()) {
                resultArea.setText("❌ 姓名不能为空！");
                return;
            }
            if (!PHONE_PATTERN.matcher(phone).matches()) {
                resultArea.setText("❌ 手机号格式不正确，必须为11位数字！");
                return;
            }
            String memberId = FileUtil.generateMemberId();
            if (FileUtil.isMemberExists(memberId, phone)) {
                resultArea.setText("❌ 该手机号已注册过会员，请勿重复办理！");
                return;
            }
            Member member = new Member(memberId, name, phone, LocalDate.now());
            FileUtil.saveMember(member);
            resultArea.setText("✅ 会员办理成功！\n\n" + member);
            nameField.setText("");
            phoneField.setText("");
        });

        panel.add(submitBtn);
        panel.add(Box.createVerticalStrut(15));
        panel.add(scrollPane);

        return panel;
    }

    /**
     * 查询会员面板
     */
    private static JPanel createQueryMemberPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        JLabel titleLabel = new JLabel("查询会员信息");
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(20));

        JRadioButton radioId = new JRadioButton("按会员ID查询", true);
        JRadioButton radioPhone = new JRadioButton("按手机号查询");
        radioId.setFont(LABEL_FONT);
        radioPhone.setFont(LABEL_FONT);
        ButtonGroup group = new ButtonGroup();
        group.add(radioId);
        group.add(radioPhone);

        panel.add(radioId);
        panel.add(radioPhone);
        panel.add(Box.createVerticalStrut(12));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        JTextField searchField = new JTextField(15);
        searchField.setFont(LABEL_FONT);
        JButton searchBtn = new JButton("查询");
        searchBtn.setFont(BUTTON_FONT);
        searchPanel.add(searchField);
        searchPanel.add(Box.createHorizontalStrut(10));
        searchPanel.add(searchBtn);
        panel.add(searchPanel);
        panel.add(Box.createVerticalStrut(15));

        JTextArea resultArea = new JTextArea(6, 30);
        resultArea.setFont(DATA_FONT);
        resultArea.setEditable(false);
        resultArea.setBackground(new Color(245, 245, 245));
        JScrollPane scrollPane = new JScrollPane(resultArea);

        searchBtn.addActionListener(e -> {
            String keyword = searchField.getText().trim();
            if (keyword.isEmpty()) {
                resultArea.setText("❌ 请输入会员ID或手机号！");
                return;
            }
            Member member;
            if (radioId.isSelected()) {
                member = FileUtil.findMemberById(keyword);
            } else {
                member = FileUtil.findMemberByPhone(keyword);
            }
            if (member != null) {
                resultArea.setText("✅ 查询结果：\n\n" + member + "\n\n该会员购物享受9折优惠。");
            } else {
                resultArea.setText("❌ 未找到该会员信息，请确认输入是否正确。");
            }
        });

        panel.add(scrollPane);
        return panel;
    }

    /**
     * 收银结算弹窗
     */
    private static void showCheckoutDialog(JFrame parent) {
        JDialog dialog = new JDialog(parent, "收银结算", true);
        dialog.setSize(600, 600);
        dialog.setLocationRelativeTo(parent);
        dialog.setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 25, 15, 25));

        // 客户类型选择
        JLabel typeLabel = new JLabel("客户类型");
        typeLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
        typeLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(typeLabel);
        mainPanel.add(Box.createVerticalStrut(8));

        JRadioButton radioMember = new JRadioButton("会员（享受9折优惠）", true);
        JRadioButton radioNonMember = new JRadioButton("非会员（无折扣）");
        radioMember.setFont(LABEL_FONT);
        radioNonMember.setFont(LABEL_FONT);
        ButtonGroup typeGroup = new ButtonGroup();
        typeGroup.add(radioMember);
        typeGroup.add(radioNonMember);
        mainPanel.add(radioMember);
        mainPanel.add(radioNonMember);
        mainPanel.add(Box.createVerticalStrut(8));

        // 会员ID输入
        JPanel memberIdPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        memberIdPanel.add(createLabel("会员ID："));
        JTextField memberIdField = new JTextField(12);
        memberIdField.setFont(LABEL_FONT);
        JButton verifyBtn = new JButton("验证");
        verifyBtn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        memberIdPanel.add(memberIdField);
        memberIdPanel.add(Box.createHorizontalStrut(8));
        memberIdPanel.add(verifyBtn);
        JLabel memberInfoLabel = createLabel("");
        memberInfoLabel.setForeground(new Color(0, 128, 0));
        mainPanel.add(memberIdPanel);
        mainPanel.add(memberInfoLabel);
        mainPanel.add(Box.createVerticalStrut(5));

        // 非会员时隐藏会员ID面板
        radioMember.addActionListener(e -> {
            memberIdField.setEnabled(true);
            verifyBtn.setEnabled(true);
        });
        radioNonMember.addActionListener(e -> {
            memberIdField.setEnabled(false);
            verifyBtn.setEnabled(false);
            memberInfoLabel.setText("");
        });

        final Member[] verifiedMember = {null};
        verifyBtn.addActionListener(e -> {
            String mid = memberIdField.getText().trim();
            if (mid.isEmpty()) {
                memberInfoLabel.setText("请输入会员ID");
                memberInfoLabel.setForeground(Color.RED);
                verifiedMember[0] = null;
                return;
            }
            Member m = FileUtil.findMemberById(mid);
            if (m != null) {
                verifiedMember[0] = m;
                memberInfoLabel.setText("✅ " + m.getName() + "，手机：" + m.getPhone() + "，享受9折优惠");
                memberInfoLabel.setForeground(new Color(0, 128, 0));
            } else {
                verifiedMember[0] = null;
                memberInfoLabel.setText("会员ID不存在！");
                memberInfoLabel.setForeground(Color.RED);
            }
        });

        mainPanel.add(Box.createVerticalStrut(10));

        // 商品输入区
        JLabel productLabel = new JLabel("商品信息");
        productLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
        productLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(productLabel);
        mainPanel.add(Box.createVerticalStrut(8));

        JPanel inputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        JTextField nameField = new JTextField(8);
        JTextField priceField = new JTextField(6);
        JTextField qtyField = new JTextField(4);
        nameField.setFont(LABEL_FONT);
        priceField.setFont(LABEL_FONT);
        qtyField.setFont(LABEL_FONT);
        inputPanel.add(createLabel("名称:"));
        inputPanel.add(nameField);
        inputPanel.add(createLabel("单价:"));
        inputPanel.add(priceField);
        inputPanel.add(createLabel("数量:"));
        inputPanel.add(qtyField);
        JButton addBtn = new JButton("添加");
        addBtn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        inputPanel.add(addBtn);
        mainPanel.add(inputPanel);
        mainPanel.add(Box.createVerticalStrut(8));

        // 商品列表表格
        String[] columns = {"序号", "商品名称", "单价(元)", "数量", "小计(元)"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable productTable = new JTable(tableModel);
        productTable.setFont(DATA_FONT);
        productTable.getTableHeader().setFont(LABEL_FONT);
        productTable.setRowHeight(25);
        productTable.getColumnModel().getColumn(0).setPreferredWidth(40);
        productTable.getColumnModel().getColumn(1).setPreferredWidth(120);
        productTable.getColumnModel().getColumn(2).setPreferredWidth(70);
        productTable.getColumnModel().getColumn(3).setPreferredWidth(50);
        productTable.getColumnModel().getColumn(4).setPreferredWidth(100);
        JScrollPane tableScroll = new JScrollPane(productTable);
        tableScroll.setPreferredSize(new Dimension(550, 150));
        tableScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(tableScroll);
        mainPanel.add(Box.createVerticalStrut(5));

        // 删除按钮
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        JButton removeBtn = new JButton("删除选中商品");
        removeBtn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        JButton clearBtn = new JButton("清空全部");
        clearBtn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        btnPanel.add(removeBtn);
        btnPanel.add(clearBtn);
        mainPanel.add(btnPanel);
        mainPanel.add(Box.createVerticalStrut(10));

        // 待存储的商品列表
        final List<Product> products = new ArrayList<>();

        addBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String priceStr = priceField.getText().trim();
            String qtyStr = qtyField.getText().trim();
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "商品名称不能为空！", "输入错误", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                BigDecimal price = new BigDecimal(priceStr);
                if (price.compareTo(BigDecimal.ZERO) <= 0) {
                    JOptionPane.showMessageDialog(dialog, "单价必须大于0！", "输入错误", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                int qty = Integer.parseInt(qtyStr);
                if (qty <= 0) {
                    JOptionPane.showMessageDialog(dialog, "数量必须大于0！", "输入错误", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                Product p = new Product(name, price.setScale(2, java.math.RoundingMode.HALF_UP), qty);
                products.add(p);
                tableModel.addRow(new Object[]{
                        tableModel.getRowCount() + 1,
                        p.getName(),
                        p.getPrice().toString(),
                        p.getQuantity(),
                        p.getSubtotal().toString()
                });
                nameField.setText("");
                priceField.setText("");
                qtyField.setText("");
                nameField.requestFocus();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "单价或数量格式不正确！", "输入错误", JOptionPane.WARNING_MESSAGE);
            }
        });

        removeBtn.addActionListener(e -> {
            int row = productTable.getSelectedRow();
            if (row >= 0) {
                products.remove(row);
                tableModel.removeRow(row);
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    tableModel.setValueAt(i + 1, i, 0);
                }
            }
        });

        clearBtn.addActionListener(e -> {
            products.clear();
            tableModel.setRowCount(0);
        });

        // 结算按钮和结果显示
        JButton checkoutBtn = new JButton("💳 结算");
        checkoutBtn.setFont(new Font("微软雅黑", Font.BOLD, 16));
        checkoutBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        checkoutBtn.setBackground(new Color(50, 150, 50));
        checkoutBtn.setForeground(Color.WHITE);
        checkoutBtn.setFocusPainted(false);
        checkoutBtn.setMaximumSize(new Dimension(200, 40));

        JTextArea resultArea = new JTextArea(8, 50);
        resultArea.setFont(DATA_FONT);
        resultArea.setEditable(false);
        resultArea.setBackground(new Color(255, 255, 240));
        JScrollPane resultScroll = new JScrollPane(resultArea);
        resultScroll.setAlignmentX(Component.LEFT_ALIGNMENT);

        checkoutBtn.addActionListener(e -> {
            if (products.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "请至少添加一件商品！", "提示", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String customerType;
            String memberId = null;
            if (radioMember.isSelected()) {
                if (verifiedMember[0] == null) {
                    JOptionPane.showMessageDialog(dialog, "请先验证会员ID！", "提示", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                customerType = "会员";
                memberId = verifiedMember[0].getMemberId();
            } else {
                customerType = "非会员";
            }

            String transactionId = FileUtil.generateTransactionId();
            List<Product> productsCopy = new ArrayList<>(products);
            Transaction transaction = new Transaction(transactionId, LocalDateTime.now(),
                    customerType, memberId, productsCopy);
            FileUtil.saveTransaction(transaction);

            StringBuilder sb = new StringBuilder();
            sb.append("✅ 交易成功！\n\n");
            sb.append("交易ID：").append(transactionId).append("\n");
            sb.append("日期时间：").append(transaction.getFormattedDateTime()).append("\n");
            sb.append("客户类型：").append(customerType);
            if (memberId != null) sb.append("（").append(memberId).append("）");
            sb.append("\n━━━━━━━━━━━━━━━━━━━━\n");
            for (int i = 0; i < productsCopy.size(); i++) {
                sb.append(String.format("  %d. %s × %d  小计：%s元\n",
                        i + 1, productsCopy.get(i).getName(),
                        productsCopy.get(i).getQuantity(),
                        productsCopy.get(i).getSubtotal()));
            }
            sb.append("━━━━━━━━━━━━━━━━━━━━\n");
            sb.append("原价总计：").append(transaction.getTotalAmount()).append("元\n");
            if (transaction.getDiscountAmount().compareTo(BigDecimal.ZERO) > 0) {
                sb.append("会员折扣：").append(transaction.getDiscountAmount()).append("元\n");
            }
            sb.append("实际支付：").append(transaction.getActualAmount()).append("元\n");
            sb.append("总件数：").append(transaction.getTotalQuantity()).append("件\n\n");
            sb.append("数据已保存到销售记录文件。");

            resultArea.setText(sb.toString());
            products.clear();
            tableModel.setRowCount(0);
            verifiedMember[0] = null;
            memberInfoLabel.setText("");
        });

        mainPanel.add(checkoutBtn);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(resultScroll);

        dialog.add(mainPanel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    /**
     * 按日期查询销售数据弹窗（表格化展示）
     */
    private static void showDateQueryDialog(JFrame parent) {
        JDialog dialog = new JDialog(parent, "按日期查询销售数据", true);
        dialog.setSize(680, 680);
        dialog.setLocationRelativeTo(parent);
        dialog.setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 25, 15, 25));

        JLabel titleLabel = new JLabel("按日期查询销售数据");
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createVerticalStrut(12));

        // ===== 日期输入栏（独立一行，自然宽度） =====
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        datePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        datePanel.add(createLabel("查询日期："));
        JTextField dateField = new JTextField(10);
        dateField.setFont(LABEL_FONT);
        dateField.setText(LocalDate.now().format(DATE_FORMAT));
        datePanel.add(dateField);
        datePanel.add(Box.createHorizontalStrut(8));
        JButton queryBtn = new JButton("查询");
        queryBtn.setFont(BUTTON_FONT);
        datePanel.add(queryBtn);
        mainPanel.add(datePanel);
        mainPanel.add(Box.createVerticalStrut(14));

        // ===== 表格1：交易汇总 =====
        JLabel summaryLabel = new JLabel("■ 交易汇总");
        summaryLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        summaryLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(summaryLabel);
        mainPanel.add(Box.createVerticalStrut(5));

        String[] columns = {"交易编号", "时间", "客户类型", "件数", "原价", "折扣", "实付"};
        DefaultTableModel summaryModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable summaryTable = new JTable(summaryModel);
        summaryTable.setFont(DATA_FONT);
        summaryTable.getTableHeader().setFont(LABEL_FONT);
        summaryTable.setRowHeight(28);
        summaryTable.getColumnModel().getColumn(0).setPreferredWidth(110);
        summaryTable.getColumnModel().getColumn(1).setPreferredWidth(65);
        summaryTable.getColumnModel().getColumn(2).setPreferredWidth(65);
        summaryTable.getColumnModel().getColumn(3).setPreferredWidth(40);
        summaryTable.getColumnModel().getColumn(4).setPreferredWidth(65);
        summaryTable.getColumnModel().getColumn(5).setPreferredWidth(65);
        summaryTable.getColumnModel().getColumn(6).setPreferredWidth(65);
        summaryTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        javax.swing.table.DefaultTableCellRenderer sumCenterRenderer = new javax.swing.table.DefaultTableCellRenderer();
        sumCenterRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < columns.length; i++) {
            summaryTable.getColumnModel().getColumn(i).setCellRenderer(sumCenterRenderer);
        }
        summaryTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane summaryScroll = new JScrollPane(summaryTable);
        summaryScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 160));
        summaryScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(summaryScroll);
        mainPanel.add(Box.createVerticalStrut(14));

        // ===== 表格2：销售统计卡片 =====
        JLabel statsCardLabel = new JLabel("■ 销售统计");
        statsCardLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        statsCardLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(statsCardLabel);
        mainPanel.add(Box.createVerticalStrut(5));

        String[] statsColumns = {"统计指标", "数值"};
        DefaultTableModel statsModel = new DefaultTableModel(statsColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable statsTable = new JTable(statsModel);
        statsTable.setFont(DATA_FONT);
        statsTable.getTableHeader().setFont(LABEL_FONT);
        statsTable.setRowHeight(28);
        statsTable.getColumnModel().getColumn(0).setPreferredWidth(200);
        statsTable.getColumnModel().getColumn(1).setPreferredWidth(400);
        statsTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        ((javax.swing.table.DefaultTableCellRenderer) statsTable.getTableHeader()
                .getDefaultRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        javax.swing.table.DefaultTableCellRenderer statsValueRenderer = new javax.swing.table.DefaultTableCellRenderer();
        statsValueRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        statsTable.getColumnModel().getColumn(1).setCellRenderer(statsValueRenderer);
        statsTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane statsScroll = new JScrollPane(statsTable);
        statsScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 105));
        statsScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(statsScroll);
        mainPanel.add(Box.createVerticalStrut(14));

        // ===== 表格3：商品明细 =====
        JLabel detailLabel = new JLabel("■ 交易商品明细");
        detailLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        detailLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(detailLabel);
        mainPanel.add(Box.createVerticalStrut(5));

        String[] detailColumns = {"交易编号", "交易时间", "商品名称", "单价", "数量", "小计"};
        DefaultTableModel detailModel = new DefaultTableModel(detailColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable detailTable = new JTable(detailModel);
        detailTable.setFont(DATA_FONT);
        detailTable.getTableHeader().setFont(LABEL_FONT);
        detailTable.setRowHeight(28);
        detailTable.getColumnModel().getColumn(0).setPreferredWidth(110);
        detailTable.getColumnModel().getColumn(1).setPreferredWidth(130);
        detailTable.getColumnModel().getColumn(2).setPreferredWidth(130);
        detailTable.getColumnModel().getColumn(3).setPreferredWidth(60);
        detailTable.getColumnModel().getColumn(4).setPreferredWidth(45);
        detailTable.getColumnModel().getColumn(5).setPreferredWidth(80);
        detailTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        javax.swing.table.DefaultTableCellRenderer detailCenterRenderer = new javax.swing.table.DefaultTableCellRenderer();
        detailCenterRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        detailTable.getColumnModel().getColumn(0).setCellRenderer(detailCenterRenderer);
        detailTable.getColumnModel().getColumn(1).setCellRenderer(detailCenterRenderer);
        detailTable.getColumnModel().getColumn(3).setCellRenderer(detailCenterRenderer);
        detailTable.getColumnModel().getColumn(4).setCellRenderer(detailCenterRenderer);
        detailTable.getColumnModel().getColumn(5).setCellRenderer(detailCenterRenderer);
        detailTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane detailScroll = new JScrollPane(detailTable);
        detailScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));
        detailScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        mainPanel.add(detailScroll);

        // ===== 提示文本（无数据时显示） =====
        JLabel emptyLabel = new JLabel("查询日期没有销售记录，请确认日期是否正确。");
        emptyLabel.setFont(LABEL_FONT);
        emptyLabel.setForeground(Color.GRAY);
        emptyLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        emptyLabel.setVisible(false);
        mainPanel.add(emptyLabel);

        // ===== 查询按钮逻辑 =====
        queryBtn.addActionListener(e -> {
            String dateStr = dateField.getText().trim();
            LocalDate queryDate;
            try {
                queryDate = LocalDate.parse(dateStr, DATE_FORMAT);
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(dialog, "日期格式不正确，请使用 yyyy-MM-dd 格式！",
                        "格式错误", JOptionPane.WARNING_MESSAGE);
                return;
            }

            List<Transaction> transactions = FileUtil.loadTransactionsByDate(queryDate);
            summaryModel.setRowCount(0);
            statsModel.setRowCount(0);
            detailModel.setRowCount(0);

            if (transactions.isEmpty()) {
                summaryLabel.setVisible(false);
                summaryScroll.setVisible(false);
                statsCardLabel.setVisible(false);
                statsScroll.setVisible(false);
                detailLabel.setVisible(false);
                detailScroll.setVisible(false);
                emptyLabel.setVisible(true);
                dialog.setSize(680, 200);
                return;
            }

            summaryLabel.setVisible(true);
            summaryScroll.setVisible(true);
            statsCardLabel.setVisible(true);
            statsScroll.setVisible(true);
            detailLabel.setVisible(true);
            detailScroll.setVisible(true);
            emptyLabel.setVisible(false);
            dialog.setSize(680, 680);

            BigDecimal totalAmount = BigDecimal.ZERO;
            int totalQty = 0;

            for (Transaction t : transactions) {
                summaryModel.addRow(new Object[]{
                        t.getTransactionId(),
                        t.getFormattedDateTime().substring(11),
                        t.getCustomerType(),
                        t.getTotalQuantity(),
                        t.getTotalAmount().toString(),
                        t.getDiscountAmount().toString(),
                        t.getActualAmount().toString()
                });

                String tid = t.getTransactionId();
                String time = t.getFormattedDateTime();
                for (Product p : t.getProducts()) {
                    detailModel.addRow(new Object[]{
                            tid,
                            time,
                            p.getName(),
                            p.getPrice().toString(),
                            p.getQuantity(),
                            p.getSubtotal().toString()
                    });
                }

                totalAmount = totalAmount.add(t.getActualAmount());
                totalQty += t.getTotalQuantity();
            }

            BigDecimal avgPrice = totalAmount.divide(BigDecimal.valueOf(transactions.size()),
                    2, java.math.RoundingMode.HALF_UP);
            String dateHeader = queryDate.toString();
            statsModel.addRow(new Object[]{"查询日期", dateHeader});
            statsModel.addRow(new Object[]{"交易笔数", transactions.size() + " 笔"});
            statsModel.addRow(new Object[]{"总销售件数", totalQty + " 件"});
            statsModel.addRow(new Object[]{"销售总额（实际收入）", totalAmount + " 元"});
            statsModel.addRow(new Object[]{"平均客单价", avgPrice + " 元"});
        });

        dialog.add(mainPanel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    /**
     * 全局销售统计弹窗（表格化展示）
     */
    private static void showGlobalStatsDialog(JFrame parent) {
        JDialog dialog = new JDialog(parent, "全局销售统计", true);
        dialog.setSize(520, 480);
        dialog.setLocationRelativeTo(parent);
        dialog.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));

        JLabel titleLabel = new JLabel("全局销售统计");
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 16));
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(titleLabel);
        panel.add(Box.createVerticalStrut(15));

        // ===== 表格1：销售总览 =====
        JLabel overviewLabel = new JLabel("■ 销售总览");
        overviewLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        overviewLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(overviewLabel);
        panel.add(Box.createVerticalStrut(5));

        String[] overviewColumns = {"统计指标", "数值"};
        DefaultTableModel overviewModel = new DefaultTableModel(overviewColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable overviewTable = new JTable(overviewModel);
        overviewTable.setFont(DATA_FONT);
        overviewTable.getTableHeader().setFont(LABEL_FONT);
        overviewTable.setRowHeight(28);
        overviewTable.getColumnModel().getColumn(0).setPreferredWidth(200);
        overviewTable.getColumnModel().getColumn(1).setPreferredWidth(250);
        // 列头居中
        ((javax.swing.table.DefaultTableCellRenderer) overviewTable.getTableHeader()
                .getDefaultRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        // 数据列居中
        javax.swing.table.DefaultTableCellRenderer centerRenderer = new javax.swing.table.DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        overviewTable.getColumnModel().getColumn(1).setCellRenderer(centerRenderer);
        // 禁止列拖动重排
        overviewTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane overviewScroll = new JScrollPane(overviewTable);
        overviewScroll.setPreferredSize(new Dimension(460, 175));
        overviewScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 175));
        overviewScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(overviewScroll);
        panel.add(Box.createVerticalStrut(18));

        // ===== 表格2：消费分类占比 =====
        JLabel categoryLabel = new JLabel("■ 消费分类占比");
        categoryLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        categoryLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(categoryLabel);
        panel.add(Box.createVerticalStrut(5));

        String[] categoryColumns = {"客户类型", "消费金额（元）", "占比"};
        DefaultTableModel categoryModel = new DefaultTableModel(categoryColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable categoryTable = new JTable(categoryModel);
        categoryTable.setFont(DATA_FONT);
        categoryTable.getTableHeader().setFont(LABEL_FONT);
        categoryTable.setRowHeight(28);
        categoryTable.getColumnModel().getColumn(0).setPreferredWidth(120);
        categoryTable.getColumnModel().getColumn(1).setPreferredWidth(150);
        categoryTable.getColumnModel().getColumn(2).setPreferredWidth(190);
        ((javax.swing.table.DefaultTableCellRenderer) categoryTable.getTableHeader()
                .getDefaultRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        javax.swing.table.DefaultTableCellRenderer catCenterRenderer = new javax.swing.table.DefaultTableCellRenderer();
        catCenterRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        categoryTable.getColumnModel().getColumn(1).setCellRenderer(catCenterRenderer);
        categoryTable.getColumnModel().getColumn(2).setCellRenderer(catCenterRenderer);
        categoryTable.getTableHeader().setReorderingAllowed(false);

        JScrollPane categoryScroll = new JScrollPane(categoryTable);
        categoryScroll.setPreferredSize(new Dimension(460, 80));
        categoryScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 80));
        categoryScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(categoryScroll);

        // ===== 提示文本（无数据时显示） =====
        JLabel emptyLabel = new JLabel("暂无任何销售记录，请先进行收银结算操作。");
        emptyLabel.setFont(LABEL_FONT);
        emptyLabel.setForeground(Color.GRAY);
        emptyLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        emptyLabel.setVisible(false);
        panel.add(emptyLabel);

        panel.add(Box.createVerticalStrut(12));

        // ===== 刷新数据按钮 =====
        JButton refreshBtn = new JButton("刷新数据");
        refreshBtn.setFont(BUTTON_FONT);
        refreshBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(refreshBtn);

        // ===== 数据加载逻辑 =====
        Runnable refreshStats = () -> {
            List<Transaction> all = FileUtil.loadAllTransactions();
            overviewModel.setRowCount(0);
            categoryModel.setRowCount(0);

            if (all.isEmpty()) {
                overviewScroll.setVisible(false);
                categoryLabel.setVisible(false);
                categoryScroll.setVisible(false);
                emptyLabel.setVisible(true);
                dialog.setSize(520, 280);
                return;
            }

            overviewScroll.setVisible(true);
            categoryLabel.setVisible(true);
            categoryScroll.setVisible(true);
            emptyLabel.setVisible(false);
            dialog.setSize(520, 480);

            BigDecimal totalAmount = BigDecimal.ZERO;
            int totalQty = 0;
            BigDecimal memberAmount = BigDecimal.ZERO;
            BigDecimal nonMemberAmount = BigDecimal.ZERO;
            BigDecimal totalDiscount = BigDecimal.ZERO;
            int memberCount = 0;
            int nonMemberCount = 0;

            for (Transaction t : all) {
                totalAmount = totalAmount.add(t.getActualAmount());
                totalQty += t.getTotalQuantity();
                if ("会员".equals(t.getCustomerType())) {
                    memberAmount = memberAmount.add(t.getActualAmount());
                    memberCount++;
                } else {
                    nonMemberAmount = nonMemberAmount.add(t.getActualAmount());
                    nonMemberCount++;
                }
                totalDiscount = totalDiscount.add(t.getDiscountAmount());
            }

            BigDecimal memberPct = memberAmount.divide(totalAmount, 4, java.math.RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100)).setScale(1, java.math.RoundingMode.HALF_UP);
            BigDecimal nonMemberPct = nonMemberAmount.divide(totalAmount, 4, java.math.RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100)).setScale(1, java.math.RoundingMode.HALF_UP);

            // 填充表格1：销售总览
            overviewModel.addRow(new Object[]{"交易总笔数", all.size() + " 笔"});
            overviewModel.addRow(new Object[]{"  其中会员交易", memberCount + " 笔"});
            overviewModel.addRow(new Object[]{"  其中非会员交易", nonMemberCount + " 笔"});
            overviewModel.addRow(new Object[]{"总销售件数", totalQty + " 件"});
            overviewModel.addRow(new Object[]{"销售总额（实际收入）", totalAmount + " 元"});
            overviewModel.addRow(new Object[]{"会员总折扣金额", totalDiscount + " 元"});

            // 填充表格2：消费分类占比
            categoryModel.addRow(new Object[]{"会员", memberAmount + "", memberPct + "%"});
            categoryModel.addRow(new Object[]{"非会员", nonMemberAmount + "", nonMemberPct + "%"});
        };

        refreshBtn.addActionListener(e -> refreshStats.run());
        refreshStats.run();

        dialog.add(panel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }
}
