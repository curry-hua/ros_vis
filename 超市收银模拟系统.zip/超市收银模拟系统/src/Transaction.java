import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * 交易实体类
 * 封装一笔完整的交易信息：交易ID、日期时间、商品明细、金额、客户类型、会员ID等
 */
public class Transaction {

    private String transactionId;

    private LocalDateTime dateTime;

    private String customerType;

    private String memberId;

    private List<Product> products;

    private BigDecimal totalAmount;

    private BigDecimal discountAmount;

    private BigDecimal actualAmount;

    private static final DateTimeFormatter DATE_TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * 构造方法：创建一笔交易
     * @param transactionId 交易ID（系统自动生成，格式：T + 日期 + 序号）
     * @param dateTime      交易日期时间
     * @param customerType  客户类型（"会员" 或 "非会员"）
     * @param memberId      会员ID（非会员时为null）
     * @param products      购买的商品列表
     */
    public Transaction(String transactionId, LocalDateTime dateTime, String customerType,
                       String memberId, List<Product> products) {
        this.transactionId = transactionId;
        this.dateTime = dateTime;
        this.customerType = customerType;
        this.memberId = memberId;
        this.products = products;
        calculateTotals();
    }

    /**
     * 计算总金额、折扣金额、实际支付金额
     * 会员享受9折优惠，非会员无折扣
     */
    private void calculateTotals() {
        totalAmount = BigDecimal.ZERO;
        for (Product p : products) {
            totalAmount = totalAmount.add(p.getSubtotal());
        }
        totalAmount = totalAmount.setScale(2, RoundingMode.HALF_UP);

        if ("会员".equals(customerType)) {
            discountAmount = totalAmount.multiply(BigDecimal.valueOf(0.1)).setScale(2, RoundingMode.HALF_UP);
        } else {
            discountAmount = BigDecimal.ZERO;
        }

        actualAmount = totalAmount.subtract(discountAmount).setScale(2, RoundingMode.HALF_UP);
    }

    public String getTransactionId() {
        return transactionId;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public String getCustomerType() {
        return customerType;
    }

    public String getMemberId() {
        return memberId;
    }

    public List<Product> getProducts() {
        return products;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    public BigDecimal getActualAmount() {
        return actualAmount;
    }

    /**
     * 获取交易总件数（所有商品数量之和）
     * @return 总件数
     */
    public int getTotalQuantity() {
        int total = 0;
        for (Product p : products) {
            total += p.getQuantity();
        }
        return total;
    }

    /**
     * 获取格式化的日期时间字符串
     * @return yyyy-MM-dd HH:mm:ss 格式的日期时间
     */
    public String getFormattedDateTime() {
        return dateTime.format(DATE_TIME_FORMAT);
    }

    /**
     * 将交易信息转换为文件存储格式
     * 格式：交易ID|日期时间|客户类型|会员ID|原价总计|折扣金额|实付金额|商品明细
     * 商品明细格式：名称:单价:数量;名称:单价:数量
     */
    public String toFileString() {
        StringBuilder productStr = new StringBuilder();
        for (int i = 0; i < products.size(); i++) {
            productStr.append(products.get(i).toFileString());
            if (i < products.size() - 1) {
                productStr.append(";");
            }
        }
        return transactionId + "|" + getFormattedDateTime() + "|" + customerType + "|"
                + (memberId != null ? memberId : "") + "|" + totalAmount + "|"
                + discountAmount + "|" + actualAmount + "|" + productStr;
    }

    /**
     * 从文件行解析出交易对象
     * @param line 文件中的一行数据
     * @return Transaction对象，解析失败返回null
     */
    public static Transaction fromFileString(String line) {
        if (line == null || line.trim().isEmpty()) {
            return null;
        }
        String[] parts = line.split("\\|");
        if (parts.length < 8) {
            return null;
        }
        try {
            String transactionId = parts[0].trim();
            LocalDateTime dateTime = LocalDateTime.parse(parts[1].trim(), DATE_TIME_FORMAT);
            String customerType = parts[2].trim();
            String memberId = parts[3].trim().isEmpty() ? null : parts[3].trim();
            // parts[4]=totalAmount, parts[5]=discountAmount, parts[6]=actualAmount 在构造中重新计算
            String productSegment = parts[7].trim();

            List<Product> products = new ArrayList<>();
            String[] productParts = productSegment.split(";");
            for (String seg : productParts) {
                Product p = Product.fromFileString(seg);
                if (p != null) {
                    products.add(p);
                }
            }
            return new Transaction(transactionId, dateTime, customerType, memberId, products);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("交易ID：").append(transactionId).append("\n");
        sb.append("日期时间：").append(getFormattedDateTime()).append("\n");
        sb.append("客户类型：").append(customerType);
        if (memberId != null && !memberId.isEmpty()) {
            sb.append("（会员ID：").append(memberId).append("）");
        }
        sb.append("\n");
        sb.append("----------------------------------------\n");
        sb.append("商品明细：\n");
        for (int i = 0; i < products.size(); i++) {
            sb.append("  ").append(i + 1).append(". ").append(products.get(i)).append("\n");
        }
        sb.append("----------------------------------------\n");
        sb.append("原价总计：").append(totalAmount).append("元\n");
        if (discountAmount.compareTo(BigDecimal.ZERO) > 0) {
            sb.append("折扣金额：").append(discountAmount).append("元\n");
        }
        sb.append("实际支付：").append(actualAmount).append("元\n");
        sb.append("总件数：").append(getTotalQuantity()).append("件");
        return sb.toString();
    }
}
