import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * 简易超市收银模拟系统 - 主系统类
 * 提供控制台菜单导航，包含会员管理、收银结算、按日期查询、全局统计四大核心功能
 */
public class CashierSystem {

    private static final Scanner SCANNER = new Scanner(System.in);

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private static final Pattern PHONE_PATTERN = Pattern.compile("^1[3-9]\\d{9}$");

    /**
     * 程序入口
     */
    public static void main(String[] args) {
        FileUtil.ensureDataFilesExist();
        System.out.println("========================================");
        System.out.println("      欢迎使用简易超市收银模拟系统");
        System.out.println("========================================");
        runMainMenu();
        System.out.println("感谢使用，再见！");
    }

    /**
     * 主菜单循环
     */
    private static void runMainMenu() {
        boolean running = true;
        while (running) {
            System.out.println();
            System.out.println("===== 简易超市收银模拟系统 =====");
            System.out.println("1. 会员管理（办理/查询会员）");
            System.out.println("2. 收银结算");
            System.out.println("3. 按日期查询销售数据");
            System.out.println("4. 全局销售统计");
            System.out.println("5. 退出系统");
            System.out.print("请选择操作：");

            String choice = readLine();
            switch (choice) {
                case "1":
                    runMemberMenu();
                    break;
                case "2":
                    runCheckout();
                    break;
                case "3":
                    runDateQuery();
                    break;
                case "4":
                    runGlobalStatistics();
                    break;
                case "5":
                    running = false;
                    break;
                default:
                    System.out.println("输入无效，请输入1-5之间的数字。");
            }
        }
    }

    /**
     * 会员管理子菜单
     */
    private static void runMemberMenu() {
        boolean back = false;
        while (!back) {
            System.out.println();
            System.out.println("===== 会员管理 =====");
            System.out.println("1. 办理新会员");
            System.out.println("2. 查询会员信息");
            System.out.println("3. 返回主菜单");
            System.out.print("请选择操作：");

            String choice = readLine();
            switch (choice) {
                case "1":
                    registerMember();
                    break;
                case "2":
                    queryMember();
                    break;
                case "3":
                    back = true;
                    break;
                default:
                    System.out.println("输入无效，请输入1-3之间的数字。");
            }
        }
    }

    /**
     * 办理新会员
     * 收集用户输入的姓名和手机号，验证后保存到会员文件
     */
    private static void registerMember() {
        System.out.println();
        System.out.println("===== 办理新会员 =====");

        System.out.print("请输入会员姓名：");
        String name = readLine().trim();
        if (name.isEmpty()) {
            System.out.println("姓名不能为空，办理取消。");
            return;
        }

        System.out.print("请输入手机号（11位数字）：");
        String phone = readLine().trim();
        if (!PHONE_PATTERN.matcher(phone).matches()) {
            System.out.println("手机号格式不正确，必须为11位中国大陆手机号，办理取消。");
            return;
        }

        String memberId = FileUtil.generateMemberId();
        if (FileUtil.isMemberExists(memberId, phone)) {
            System.out.println("该手机号已注册过会员，请勿重复办理。");
            return;
        }

        LocalDate registrationDate = LocalDate.now();
        Member member = new Member(memberId, name, phone, registrationDate);
        FileUtil.saveMember(member);

        System.out.println();
        System.out.println("会员办理成功！");
        System.out.println(member);
    }

    /**
     * 查询会员信息
     * 支持通过会员ID或手机号查询
     */
    private static void queryMember() {
        System.out.println();
        System.out.println("===== 查询会员信息 =====");
        System.out.println("1. 按会员ID查询");
        System.out.println("2. 按手机号查询");
        System.out.print("请选择查询方式：");

        String choice = readLine();
        Member member = null;

        switch (choice) {
            case "1":
                System.out.print("请输入会员ID：");
                String memberId = readLine().trim();
                member = FileUtil.findMemberById(memberId);
                break;
            case "2":
                System.out.print("请输入手机号：");
                String phone = readLine().trim();
                member = FileUtil.findMemberByPhone(phone);
                break;
            default:
                System.out.println("输入无效。");
                return;
        }

        if (member != null) {
            System.out.println();
            System.out.println("查询结果：");
            System.out.println(member);
            System.out.println("该会员购物享受9折优惠。");
        } else {
            System.out.println("未找到该会员信息，请确认输入是否正确。");
        }
    }

    /**
     * 收银结算流程
     * 选择客户类型 → 验证会员身份 → 输入商品 → 计算金额 → 保存交易记录
     */
    private static void runCheckout() {
        System.out.println();
        System.out.println("===== 收银结算 =====");

        // 选择客户类型
        System.out.print("请选择客户类型（1-会员，2-非会员）：");
        String typeChoice = readLine();
        String customerType;
        String memberId = null;
        Member member = null;

        if ("1".equals(typeChoice)) {
            customerType = "会员";
            // 验证会员身份
            System.out.print("请输入会员ID：");
            memberId = readLine().trim();
            member = FileUtil.findMemberById(memberId);
            if (member == null) {
                System.out.println("会员ID不存在，请先办理会员或确认ID正确。");
                return;
            }
            System.out.println("会员信息：" + member.getName() + "，手机号：" + member.getPhone() + "，享受9折优惠");
        } else if ("2".equals(typeChoice)) {
            customerType = "非会员";
        } else {
            System.out.println("输入无效，请选择1或2。");
            return;
        }

        // 输入商品信息
        System.out.println();
        System.out.println("请输入商品信息（输入0结束）：");
        List<Product> products = new ArrayList<>();
        int itemIndex = 1;

        while (true) {
            System.out.print("商品" + itemIndex + " 名称：");
            String name = readLine().trim();
            if ("0".equals(name)) {
                if (products.isEmpty()) {
                    System.out.println("至少需要购买一件商品。");
                    return;
                }
                break;
            }
            if (name.isEmpty()) {
                System.out.println("商品名称不能为空，请重新输入。");
                continue;
            }

            BigDecimal price = readPositiveBigDecimal("商品" + itemIndex + " 单价（元）：");
            if (price == null) {
                continue;
            }

            int quantity = readPositiveInt("商品" + itemIndex + " 数量：");
            if (quantity <= 0) {
                continue;
            }

            products.add(new Product(name, price, quantity));
            System.out.println("  已添加：" + name + "，单价：" + price + "元，数量：" + quantity);
            itemIndex++;
        }

        // 创建交易
        String transactionId = FileUtil.generateTransactionId();
        LocalDateTime now = LocalDateTime.now();
        Transaction transaction = new Transaction(transactionId, now, customerType, memberId, products);

        // 显示商品明细
        System.out.println();
        System.out.println("商品明细：");
        for (int i = 0; i < products.size(); i++) {
            System.out.println((i + 1) + ". " + products.get(i));
        }
        System.out.println("----------------------------------------");
        System.out.println("原价总计：" + transaction.getTotalAmount() + "元");
        if (transaction.getDiscountAmount().compareTo(BigDecimal.ZERO) > 0) {
            System.out.println("会员折扣：" + transaction.getDiscountAmount() + "元");
        }
        System.out.println("实际支付：" + transaction.getActualAmount() + "元");

        // 保存交易记录
        FileUtil.saveTransaction(transaction);

        System.out.println();
        System.out.println("交易成功！交易ID：" + transactionId
                + "，日期：" + transaction.getFormattedDateTime());
        System.out.println("数据已保存到销售记录文件。");
    }

    /**
     * 按日期查询销售数据
     * 显示当日所有交易、总销售额、总件数、交易笔数、平均客单价
     */
    private static void runDateQuery() {
        System.out.println();
        System.out.println("===== 按日期查询销售数据 =====");
        System.out.print("请输入查询日期（格式：yyyy-MM-dd，如 2026-05-15）：");
        String dateStr = readLine().trim();

        LocalDate queryDate;
        try {
            queryDate = LocalDate.parse(dateStr, DATE_FORMAT);
        } catch (DateTimeParseException e) {
            System.out.println("日期格式不正确，请使用 yyyy-MM-dd 格式。");
            return;
        }

        List<Transaction> transactions = FileUtil.loadTransactionsByDate(queryDate);

        if (transactions.isEmpty()) {
            System.out.println("查询日期 " + queryDate + " 没有销售记录。");
            return;
        }

        System.out.println();
        System.out.println("===== " + queryDate + " 销售记录 =====");
        System.out.println();

        BigDecimal totalActualAmount = BigDecimal.ZERO;
        int totalQuantity = 0;

        for (Transaction t : transactions) {
            System.out.println("【" + t.getTransactionId() + "】 "
                    + t.getFormattedDateTime() + "  " + t.getCustomerType());
            List<Product> products = t.getProducts();
            for (Product p : products) {
                System.out.println("  - " + p.getName() + " × " + p.getQuantity()
                        + "  单价：" + p.getPrice() + "  小计：" + p.getSubtotal() + "元");
            }
            if (t.getDiscountAmount().compareTo(BigDecimal.ZERO) > 0) {
                System.out.println("  原价：" + t.getTotalAmount() + "元  折扣："
                        + t.getDiscountAmount() + "元  实付：" + t.getActualAmount() + "元");
            } else {
                System.out.println("  合计：" + t.getActualAmount() + "元");
            }
            System.out.println();

            totalActualAmount = totalActualAmount.add(t.getActualAmount());
            totalQuantity += t.getTotalQuantity();
        }

        BigDecimal avgPrice = BigDecimal.ZERO;
        if (!transactions.isEmpty()) {
            avgPrice = totalActualAmount.divide(BigDecimal.valueOf(transactions.size()),
                    2, RoundingMode.HALF_UP);
        }

        System.out.println("===== " + queryDate + " 销售统计 =====");
        System.out.println("交易笔数：" + transactions.size() + "笔");
        System.out.println("总销售件数：" + totalQuantity + "件");
        System.out.println("销售总额（实际收入）：" + totalActualAmount + "元");
        System.out.println("平均客单价：" + avgPrice + "元");
    }

    /**
     * 全局销售统计查询
     * 显示总销售额、总件数、交易总笔数、会员/非会员消费占比、会员总折扣金额
     */
    private static void runGlobalStatistics() {
        System.out.println();
        System.out.println("===== 全局销售统计 =====");

        List<Transaction> allTransactions = FileUtil.loadAllTransactions();

        if (allTransactions.isEmpty()) {
            System.out.println("暂无任何销售记录。");
            return;
        }

        BigDecimal totalActualAmount = BigDecimal.ZERO;
        int totalQuantity = 0;
        BigDecimal memberAmount = BigDecimal.ZERO;
        BigDecimal nonMemberAmount = BigDecimal.ZERO;
        BigDecimal totalDiscount = BigDecimal.ZERO;
        int memberTransactionCount = 0;
        int nonMemberTransactionCount = 0;

        for (Transaction t : allTransactions) {
            totalActualAmount = totalActualAmount.add(t.getActualAmount());
            totalQuantity += t.getTotalQuantity();

            if ("会员".equals(t.getCustomerType())) {
                memberAmount = memberAmount.add(t.getActualAmount());
                memberTransactionCount++;
            } else {
                nonMemberAmount = nonMemberAmount.add(t.getActualAmount());
                nonMemberTransactionCount++;
            }

            totalDiscount = totalDiscount.add(t.getDiscountAmount());
        }

        BigDecimal memberPercent = BigDecimal.ZERO;
        BigDecimal nonMemberPercent = BigDecimal.ZERO;
        if (totalActualAmount.compareTo(BigDecimal.ZERO) > 0) {
            memberPercent = memberAmount.divide(totalActualAmount, 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100)).setScale(1, RoundingMode.HALF_UP);
            nonMemberPercent = nonMemberAmount.divide(totalActualAmount, 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100)).setScale(1, RoundingMode.HALF_UP);
        }

        System.out.println();
        System.out.println("交易总笔数：" + allTransactions.size() + "笔");
        System.out.println("  会员交易：" + memberTransactionCount + "笔");
        System.out.println("  非会员交易：" + nonMemberTransactionCount + "笔");
        System.out.println("总销售件数：" + totalQuantity + "件");
        System.out.println("销售总额（实际收入）：" + totalActualAmount + "元");
        System.out.println("会员消费总额：" + memberAmount + "元（占比 " + memberPercent + "%）");
        System.out.println("非会员消费总额：" + nonMemberAmount + "元（占比 " + nonMemberPercent + "%）");
        System.out.println("会员总折扣金额：" + totalDiscount + "元");
    }

    /**
     * 读取一行用户输入，去除首尾空白
     * @return 用户输入的字符串
     */
    private static String readLine() {
        String line = SCANNER.nextLine();
        return line == null ? "" : line.trim();
    }

    /**
     * 读取一个正数金额（BigDecimal），含输入验证
     * @param prompt 提示信息
     * @return 正数金额，输入无效时返回null
     */
    private static BigDecimal readPositiveBigDecimal(String prompt) {
        System.out.print(prompt);
        String input = readLine();
        if (input.isEmpty()) {
            System.out.println("金额不能为空，请重新输入。");
            return null;
        }
        try {
            BigDecimal value = new BigDecimal(input);
            if (value.compareTo(BigDecimal.ZERO) <= 0) {
                System.out.println("金额必须大于0，请重新输入。");
                return null;
            }
            return value.setScale(2, RoundingMode.HALF_UP);
        } catch (NumberFormatException e) {
            System.out.println("金额格式不正确，请输入有效的数字。");
            return null;
        }
    }

    /**
     * 读取一个正整数，含输入验证
     * @param prompt 提示信息
     * @return 正整数，输入无效时返回-1
     */
    private static int readPositiveInt(String prompt) {
        System.out.print(prompt);
        String input = readLine();
        if (input.isEmpty()) {
            System.out.println("数量不能为空，请重新输入。");
            return -1;
        }
        try {
            int value = Integer.parseInt(input);
            if (value <= 0) {
                System.out.println("数量必须大于0，请重新输入。");
                return -1;
            }
            return value;
        } catch (NumberFormatException e) {
            System.out.println("数量格式不正确，请输入有效的整数。");
            return -1;
        }
    }
}
