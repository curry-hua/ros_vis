import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 商品实体类
 * 封装单个商品的信息：名称、单价、数量，并提供小计金额计算
 */
public class Product {

    private String name;

    private BigDecimal price;

    private int quantity;

    /**
     * 构造方法：创建一个商品对象
     * @param name     商品名称
     * @param price    商品单价（元）
     * @param quantity 购买数量
     */
    public Product(String name, BigDecimal price, int quantity) {
        this.name = name;
        this.price = price.setScale(2, RoundingMode.HALF_UP);
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    /**
     * 计算该商品的小计金额（单价 × 数量）
     * @return 小计金额，保留2位小数
     */
    public BigDecimal getSubtotal() {
        return price.multiply(BigDecimal.valueOf(quantity)).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * 将商品信息转换为文件存储格式
     * 格式：商品名称:单价:数量
     */
    public String toFileString() {
        return name + ":" + price + ":" + quantity;
    }

    /**
     * 从文件片段解析出商品对象
     * @param segment 格式为"商品名称:单价:数量"的字符串
     * @return Product对象，解析失败返回null
     */
    public static Product fromFileString(String segment) {
        if (segment == null || segment.trim().isEmpty()) {
            return null;
        }
        String[] parts = segment.split(":");
        if (parts.length < 3) {
            return null;
        }
        try {
            String name = parts[0].trim();
            BigDecimal price = new BigDecimal(parts[1].trim());
            int quantity = Integer.parseInt(parts[2].trim());
            return new Product(name, price, quantity);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return name + " × " + quantity + "，单价：" + price + "元，小计：" + getSubtotal() + "元";
    }
}
