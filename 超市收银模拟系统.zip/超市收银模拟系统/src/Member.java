import java.time.LocalDate;

/**
 * 会员实体类
 * 用于封装会员的基本信息：会员ID、姓名、手机号、注册日期
 */
public class Member {

    private String memberId;

    private String name;

    private String phone;

    private LocalDate registrationDate;

    /**
     * 构造方法：创建一个会员对象
     * @param memberId         会员ID（系统自动生成，格式：M + 日期 + 序号）
     * @param name             会员姓名
     * @param phone            手机号
     * @param registrationDate 注册日期
     */
    public Member(String memberId, String name, String phone, LocalDate registrationDate) {
        this.memberId = memberId;
        this.name = name;
        this.phone = phone;
        this.registrationDate = registrationDate;
    }

    public String getMemberId() {
        return memberId;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    /**
     * 将会员信息转换为文件存储格式
     * 格式：会员ID|姓名|手机号|注册日期
     */
    public String toFileString() {
        return memberId + "|" + name + "|" + phone + "|" + registrationDate;
    }

    /**
     * 从文件行解析出会员对象
     * @param line 文件中的一行数据
     * @return Member对象，解析失败返回null
     */
    public static Member fromFileString(String line) {
        if (line == null || line.trim().isEmpty()) {
            return null;
        }
        String[] parts = line.split("\\|");
        if (parts.length < 4) {
            return null;
        }
        try {
            String memberId = parts[0].trim();
            String name = parts[1].trim();
            String phone = parts[2].trim();
            LocalDate registrationDate = LocalDate.parse(parts[3].trim());
            return new Member(memberId, name, phone, registrationDate);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return "会员ID：" + memberId
                + "，姓名：" + name
                + "，手机号：" + phone
                + "，注册日期：" + registrationDate;
    }
}
